/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ProjectEuler.P001_009;

import java.math.BigInteger;
import java.util.ArrayList;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author ismaf
 */
public class Problem001NGTest {
    
    public Problem001NGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of solution1 method, of class Problem001.
     */
    @Test
    public void testSolution1_3args_1() {
        System.out.println("solution1");
        long a = 0L;
        long b = 0L;
        long below = 0L;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solution1(a, b, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution1 method, of class Problem001.
     */
    @Test
    public void testSolution1_3args_2() {
        System.out.println("solution1");
        BigInteger a = null;
        BigInteger b = null;
        BigInteger below = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solution1(a, b, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution1 method, of class Problem001.
     */
    @Test
    public void testSolution1_4args_1() {
        System.out.println("solution1");
        long a = 0L;
        long b = 0L;
        long from = 0L;
        long below = 0L;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solution1(a, b, from, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution1 method, of class Problem001.
     */
    @Test
    public void testSolution1_4args_2() {
        System.out.println("solution1");
        BigInteger a = null;
        BigInteger b = null;
        BigInteger from = null;
        BigInteger below = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solution1(a, b, from, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution2 method, of class Problem001.
     */
    @Test
    public void testSolution2_3args_1() {
        System.out.println("solution2");
        long a = 0L;
        long b = 0L;
        long below = 0L;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solution2(a, b, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution2 method, of class Problem001.
     */
    @Test
    public void testSolution2_3args_2() {
        System.out.println("solution2");
        BigInteger a = null;
        BigInteger b = null;
        BigInteger below = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solution2(a, b, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution2 method, of class Problem001.
     */
    @Test
    public void testSolution2_4args_1() {
        System.out.println("solution2");
        long a = 0L;
        long b = 0L;
        long from = 0L;
        long below = 0L;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solution2(a, b, from, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution2 method, of class Problem001.
     */
    @Test
    public void testSolution2_4args_2() {
        System.out.println("solution2");
        BigInteger a = null;
        BigInteger b = null;
        BigInteger from = null;
        BigInteger below = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solution2(a, b, from, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution3 method, of class Problem001.
     */
    @Test
    public void testSolution3_3args_1() {
        System.out.println("solution3");
        long a = 0L;
        long b = 0L;
        long below = 0L;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solution3(a, b, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution3 method, of class Problem001.
     */
    @Test
    public void testSolution3_4args_1() {
        System.out.println("solution3");
        long a = 0L;
        long b = 0L;
        long from = 0L;
        long below = 0L;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solution3(a, b, from, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution3 method, of class Problem001.
     */
    @Test
    public void testSolution3_3args_2() {
        System.out.println("solution3");
        BigInteger a = null;
        BigInteger b = null;
        BigInteger below = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solution3(a, b, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solution3 method, of class Problem001.
     */
    @Test
    public void testSolution3_4args_2() {
        System.out.println("solution3");
        BigInteger a = null;
        BigInteger b = null;
        BigInteger from = null;
        BigInteger below = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solution3(a, b, from, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_0args() {
        System.out.println("solve");
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solve();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_Problem001Algorithm() {
        System.out.println("solve");
        Problem001.Algorithm algorithm = null;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solve(algorithm);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_3args_1() {
        System.out.println("solve");
        long a = 0L;
        long b = 0L;
        long below = 0L;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solve(a, b, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_4args_1() {
        System.out.println("solve");
        long a = 0L;
        long b = 0L;
        long below = 0L;
        Problem001.Algorithm algorithm = null;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solve(a, b, below, algorithm);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_4args_2() {
        System.out.println("solve");
        long a = 0L;
        long b = 0L;
        long from = 0L;
        long below = 0L;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solve(a, b, from, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_5args_1() {
        System.out.println("solve");
        long a = 0L;
        long b = 0L;
        long from = 0L;
        long below = 0L;
        Problem001.Algorithm algorithm = null;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solve(a, b, from, below, algorithm);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_3args_2() {
        System.out.println("solve");
        BigInteger a = null;
        BigInteger b = null;
        BigInteger below = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solve(a, b, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_4args_3() {
        System.out.println("solve");
        BigInteger a = null;
        BigInteger b = null;
        BigInteger below = null;
        Problem001.Algorithm algorithm = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solve(a, b, below, algorithm);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_4args_4() {
        System.out.println("solve");
        BigInteger a = null;
        BigInteger b = null;
        BigInteger from = null;
        BigInteger below = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solve(a, b, from, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_5args_2() {
        System.out.println("solve");
        BigInteger a = null;
        BigInteger b = null;
        BigInteger from = null;
        BigInteger below = null;
        Problem001.Algorithm algorithm = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solve(a, b, from, below, algorithm);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_3args_3() {
        System.out.println("solve");
        ArrayList<Long> values = null;
        long from = 0L;
        long below = 0L;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solve(values, from, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_4args_5() {
        System.out.println("solve");
        ArrayList<Long> values = null;
        long from = 0L;
        long below = 0L;
        Problem001.Algorithm algorithm = null;
        Problem001 instance = new Problem001();
        long expResult = 0L;
        long result = instance.solve(values, from, below, algorithm);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_3args_4() {
        System.out.println("solve");
        ArrayList<BigInteger> values = null;
        BigInteger from = null;
        BigInteger below = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solve(values, from, below);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of solve method, of class Problem001.
     */
    @Test
    public void testSolve_4args_6() {
        System.out.println("solve");
        ArrayList<BigInteger> values = null;
        BigInteger from = null;
        BigInteger below = null;
        Problem001.Algorithm algorithm = null;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.solve(values, from, below, algorithm);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getValue method, of class Problem001.
     */
    @Test
    public void testGetValue() {
        System.out.println("getValue");
        ArrayList<BigInteger> values = null;
        BigInteger from = null;
        BigInteger below = null;
        long nValue = 0L;
        Problem001 instance = new Problem001();
        BigInteger expResult = null;
        BigInteger result = instance.getValue(values, from, below, nValue);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFirstValues method, of class Problem001.
     */
    @Test
    public void testGetFirstValues() {
        System.out.println("getFirstValues");
        ArrayList<BigInteger> values = null;
        BigInteger from = null;
        BigInteger below = null;
        long nValues = 0L;
        Problem001 instance = new Problem001();
        ArrayList expResult = null;
        ArrayList result = instance.getFirstValues(values, from, below, nValues);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getLastValues method, of class Problem001.
     */
    @Test
    public void testGetLastValues() {
        System.out.println("getLastValues");
        ArrayList<BigInteger> values = null;
        BigInteger from = null;
        BigInteger below = null;
        long nValues = 0L;
        Problem001 instance = new Problem001();
        ArrayList expResult = null;
        ArrayList result = instance.getLastValues(values, from, below, nValues);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
