/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dialogs;

import javafx.event.ActionEvent;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ismael.flores
 */
public class JProjectEulerP001ControllerIT {
    
    public JProjectEulerP001ControllerIT() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of updateButtons method, of class JProjectEulerP001Controller.
     */
    @Test
    public void testUpdateButtons() {
        System.out.println("updateButtons");
        JProjectEulerP001Controller instance = new JProjectEulerP001Controller();
        instance.updateButtons();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of initialize method, of class JProjectEulerP001Controller.
     */
    @Test
    public void testInitialize() {
        System.out.println("initialize");
        JProjectEulerP001Controller instance = new JProjectEulerP001Controller();
        instance.initialize();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of onAddToList method, of class JProjectEulerP001Controller.
     */
    @Test
    public void testOnAddToList() {
        System.out.println("onAddToList");
        ActionEvent event = null;
        JProjectEulerP001Controller instance = new JProjectEulerP001Controller();
        instance.onAddToList(event);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of onRemoveFromList method, of class JProjectEulerP001Controller.
     */
    @Test
    public void testOnRemoveFromList() {
        System.out.println("onRemoveFromList");
        ActionEvent event = null;
        JProjectEulerP001Controller instance = new JProjectEulerP001Controller();
        instance.onRemoveFromList(event);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of onCalculate method, of class JProjectEulerP001Controller.
     */
    @Test
    public void testOnCalculate() throws InterruptedException {
        System.out.println("onCalculate");
        ActionEvent event = null;
        JProjectEulerP001Controller instance = new JProjectEulerP001Controller();
        instance.onCalculate(event);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of onCancel method, of class JProjectEulerP001Controller.
     */
    @Test
    public void testOnCancel() {
        System.out.println("onCancel");
        ActionEvent event = null;
        JProjectEulerP001Controller instance = new JProjectEulerP001Controller();
        instance.onCancel(event);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
